#Launch an Instance in a private subnet.
$ aws ec2 run-instances --image-id ami-01d025118d8e760db --subnet-id [privatesubnet-
id] --instance-type t3.micro

#Deploying a Stack to Multiple Regions
$ aws cloudformation deploy --template-file "app-stack-west-1.json" \
--stack-name "app-stack-west" \
--region us-west-1 \
--parameter-overrides Key="ALBCertificateArn",Value="arn:aws:acm:us-west-
1:x:certificate/yourcertificatehere" Key="KeyName",Value="yourkeypairname"
$ aws cloudformation deploy --template-file "app-stack-east-1.json" \
--stack-name "app-stack-east" \
--region us-east-1 \
--parameter-overrides Key="ALBCertificateArn",Value="arn:aws:acm:us-east-
1:x:certificate/yourcertificatehere" Key="KeyName",Value="yourkeypairname"

